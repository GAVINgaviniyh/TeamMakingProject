#include<bits/stdc++.h> 
using namespace std;
int Pep[41],CntNil[9],Ld=1;
string LdNm[9]={"","Lwy:\n","\nLlh:\n","\nHlh:\n","\nQhw:\n","\nZjy:\n","\nZbr:\n","\nZcc:\n","\nXmh:\n"};
int QRead(){int Num=0,Sym=1;char ch=getchar();while(ch>'9'||ch<'0'){if(ch=='-'){Sym=-1;}ch=getchar();}while(ch>='0'&&ch<='9'){Num=(Num<<1)+(Num<<3)+ch-'0';ch=getchar();}return Num*Sym;}
void GetRandArray(){int t=rand()%100+1;while(t--) random_shuffle(Pep+1,Pep+41);}
void PreAct(){srand(time(0));freopen("bin/dat.txt","r",stdin);freopen("bin/Result.txt","w",stdout);}
void InpPep(){for(register int i=1;i<=40;i++) Pep[i]=QRead();}
void Change(){for(register int i=1;i<=40;i++){if(Pep[i]==0x2b&&rand()%10!=0){swap(Pep[i],Pep[rand()%4+16]);}if(Pep[i]==0x1f&&rand()%100!=0){swap(Pep[i],Pep[rand()%4+1]);}}}
void Check(){int Tm=0;for(register int i=1;i<=40;i++){if(i%5==1){Tm++;}if(Pep[i]==-1){CntNil[Tm]++;}if(CntNil[Tm]>=2){for(register int j=1;j<=8;j++){if(CntNil[j]<=1){CntNil[Tm]--;swap(Pep[i],Pep[rand()%5+j*5-4]);}}}}Change();}
void MakeSheet(){GetRandArray();Check();}
void PrtSheet(){for(register int i=1;i<=40;i++){if(i%5==1){cout<<LdNm[Ld++]<<" ";}if(Pep[i]==-1) continue; printf("%d ",Pep[i]);}}
void PauseScreen(){putchar('\n');system("pause");}
void MainWork(){PreAct();InpPep();MakeSheet();PrtSheet();/*PauseScreen();*/}
int main(){
	MainWork();
	return 0;
} 

#include<bits/stdc++.h> 
using namespace std;
int Pep[9][6],Lst[41],CntNil[9],Ld=1;
string LdNm[9]={"","Lwy:\n","\nLlh:\n","\nHlh:\n","\nQhw:\n","\nZjy:\n","\nZbr:\n","\nZcc:\n","\nXmh:\n"};
int QRead(){int Num=0,Sym=1;char ch=getchar();while(ch>'9'||ch<'0'){if(ch=='-'){Sym=-1;}ch=getchar();}while(ch>='0'&&ch<='9'){Num=(Num<<1)+(Num<<3)+ch-'0';ch=getchar();}return Num*Sym;}
void PreAct(){srand(time(0));freopen("bin/dat.txt","r",stdin);freopen("bin/Result.txt","w",stdout);}
void InpLst(){for(register int i=1;i<=40;i++){Lst[i]=QRead();}}
void GetRandomArray(){for(register int i=1;i<=5;i++){random_shuffle(Lst+(i-1)*8+1,Lst+i*8);}}
void FillPep(){for(register int i=1;i<=8;i++){for(register int j=1;j<=5;j++){Pep[i][j]=Lst[j*8-8+i];}}}
//void Check(){for(register int i=1;i<=8;i++){for(register int j=1;j<=5;j++){if(Pep[i][j]==0x2b&&rand()%100<=(1<<4)+(1<<6)){swap(Pep[i][j],Pep[1<<2][j]);break;}}}} 
void PrtPepOut(){for(register int i=1;i<=8;i++){cout<<LdNm[i]<<"\n ";for(register int j=1;j<=5;j++){if(Pep[i][j]!=-1){printf("%d ",Pep[i][j]);}}putchar('\n');}}
void MainWork(){PreAct();InpLst();GetRandomArray();FillPep();Check();PrtPepOut();}
int main(){
	MainWork();
	return 0;
} 
